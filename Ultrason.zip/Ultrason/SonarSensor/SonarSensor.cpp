//#include "SonarSensor.h"
#include <Arduino.h>
#include <Servo.h>

class SonarSensor {
  private:
    const int DIST_OBS = 15;
    const int numOfReadings = 20;
    int readings[20];
    int arrayIndex = 0;
    int total = 0;
    int averageDistance = 0;
    bool obs = false;
    
    int echoPin;
    int initPin;
    unsigned long pulseTime = 0;
    unsigned long distance = 0;

    int redLEDValue = 0;

  public:
    SonarSensor(int echoPin, int initPin) {
      this->echoPin = echoPin;
      this->initPin = initPin;
    }

    void setup() {
      pinMode(initPin, OUTPUT);
      pinMode(echoPin, INPUT);
      for (int thisReading = 0; thisReading < numOfReadings; thisReading++) {
        readings[thisReading] = 0;
      }
      Serial.begin(19200);
    }

    int mesure() {
      digitalWrite(initPin, HIGH);
      delayMicroseconds(10);
      digitalWrite(initPin, LOW);
      pulseTime = pulseIn(echoPin, HIGH);
      distance = pulseTime / 58;
      total = total - readings[arrayIndex];
      readings[arrayIndex] = distance;
      total = total + readings[arrayIndex];
      arrayIndex = arrayIndex + 1;
      if (arrayIndex >= numOfReadings) {
        arrayIndex = 0;
      }
      averageDistance = total / numOfReadings;

      Serial.println(averageDistance, DEC);

      if (averageDistance < DIST_OBS && averageDistance >= 1) {
        obs = true;
        Serial.println("obstacle");
      } else {
        obs = false;
      }

      delay(10);
      return averageDistance;
    }
};
