#ifndef SonarSensor_h
#define SonarSensor_h

#include <Arduino.h>

class SonarSensor {
  private:
    const int DIST_OBS = 15;
    const int numOfReadings = 20;
    int readings[20];
    int arrayIndex = 0;
    int total = 0;
    int averageDistance = 0;
    bool obs = false;
    
    int echoPin;
    int initPin;
    unsigned long pulseTime = 0;
    unsigned long distance = 0;

    int redLEDPin;
    int redLEDValue = 0;

  public:
    SonarSensor(int echoPin, int initPin);
    void setup();
    int mesure();
};

#endif
